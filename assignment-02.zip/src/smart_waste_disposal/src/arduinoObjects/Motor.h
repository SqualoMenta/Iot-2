#ifndef __MOTOR__
#define __MOTOR__

class Motor {
   public:
    virtual void open();
    virtual void close();
};

#endif